package com.cf.glesdemo;

import android.app.Application;
import android.util.Log;

/**
 * Created by ccfyyn on 18/7/13.
 */

public class MainApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        Log.e("MainApplication", "" + Thread.currentThread().toString());
    }
}
