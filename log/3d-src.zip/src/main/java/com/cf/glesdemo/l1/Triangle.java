package com.cf.glesdemo.l1;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;

import com.cf.glesdemo.base.BaseShape;

public class Triangle extends BaseShape {
	private final String TAG = "Triangle";
	// 顶点着色器
	private final String vertexShaderCode = "attribute vec4 vPosition;" //
			+ "void main() {"//
			+ "  gl_Position = vPosition;" //
			+ "}";
	// 片元着色器
	private final String fragmentShaderCode = "precision mediump float;" //
			+ "uniform vec4 vColor;"//
			+ "void main() {" //
			+ "  gl_FragColor = vColor;" //
			+ "}";

	// 绘制顺序为逆时针
	static float triangleCoords[] = {
			//
			0.0f, 0.5f, 0.0f, // top
			-0.5f, -0.5f, 0.0f, // bottomLeft
			0.5f, -0.5f, 0.0f // bottomRight
	};
	// GLES程序id
	private int mProgram;
	// 片元着色器填充颜色
	private float color[] = { 1.0f, 1.0f, 1.0f, 1.0f };
	// 顶点坐标buffer，将传递给native层
	private FloatBuffer vertexBuffer;
	// 顶点着色器句柄
	private int mPositionHandle;
	// 顶点着色器句柄
	private int mColorHandle;
	// 顶点偏移量
	private int vertexStride = COORDS_PER_VERTEX * 4;
	// 顶点个数
	private int vertexCount = triangleCoords.length / COORDS_PER_VERTEX;
	// 每个顶点坐标个数
	private static final int COORDS_PER_VERTEX = 3;

	public Triangle(GLSurfaceView view) {
		super(view);
		System.out.println(TAG + ": Constructor#" + Thread.currentThread());
	}

	@Override
	public void onDrawFrame(GL10 arg0) {
		System.out.println(TAG + ": onDrawFrame#" + Thread.currentThread());
		GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);
		// 将程序加入到OpenGLES2.0环境
		GLES20.glUseProgram(mProgram);
		// 获取顶点着色器的vPosition成员句柄
		mPositionHandle = GLES20.glGetAttribLocation(mProgram, "vPosition");
		// 启用三角形顶点的句柄
		GLES20.glEnableVertexAttribArray(mPositionHandle);
		// 准备三角形的坐标数据
		GLES20.glVertexAttribPointer(mPositionHandle, COORDS_PER_VERTEX,
				GLES20.GL_FLOAT, false, vertexStride, vertexBuffer);
		// 获取片元着色器的vColor成员的句柄
		mColorHandle = GLES20.glGetUniformLocation(mProgram, "vColor");
		// 设置绘制三角形的颜色
		GLES20.glUniform4fv(mColorHandle, 1, color, 0);
		// 绘制三角形
		GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, vertexCount);
		// 禁止顶点数组的句柄
		GLES20.glDisableVertexAttribArray(mPositionHandle);
	}

	@Override
	public void onSurfaceChanged(GL10 arg0, int width, int height) {
		System.out
				.println(TAG + ": onSurfaceChanged#" + Thread.currentThread());
		GLES20.glViewport(0, 0, width, height);
	}

	@Override
	public void onSurfaceCreated(GL10 arg0, EGLConfig arg1) {
		System.out
				.println(TAG + ": onSurfaceCreated#" + Thread.currentThread());
		// 将背景设置为灰色
		GLES20.glClearColor(0.5f, 0.5f, 0.5f, 1.0f);
		// 申请底层空间
		ByteBuffer bb = ByteBuffer.allocateDirect(triangleCoords.length * 4);
		bb.order(ByteOrder.nativeOrder());
		// 将坐标数据转换为FloatBuffer，用以传入给OpenGL ES程序
		vertexBuffer = bb.asFloatBuffer();
		vertexBuffer.put(triangleCoords);
		vertexBuffer.position(0);
		int vertexShader = loadShader(GLES20.GL_VERTEX_SHADER, vertexShaderCode);
		int fragmentShader = loadShader(GLES20.GL_FRAGMENT_SHADER,
				fragmentShaderCode);
		// 创建一个空的OpenGLES程序
		mProgram = GLES20.glCreateProgram();
		// 将顶点着色器加入到程序
		GLES20.glAttachShader(mProgram, vertexShader);
		// 将片元着色器加入到程序中
		GLES20.glAttachShader(mProgram, fragmentShader);
		// 连接到着色器程序
		GLES20.glLinkProgram(mProgram);
	}

}

//
// 实现GLSurfaceView的Render，在Render中完成三角形的绘制，具体行为有：
// 加载顶点和片元着色器。
// 确定需要绘制图形的坐标和颜色数据。
// 创建program对象，连接顶点和片元着色器，链接program对象。
// 设置视图窗口(ViewPort)。
// 将坐标数据颜色数据传入OpenGL ES程序中。
// 使颜色缓冲区的内容显示到屏幕上。
//
