package com.cf.glesdemo.l5;

import java.nio.FloatBuffer;
import java.util.ArrayList;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import android.util.Log;

import com.cf.glesdemo.base.BaseShape;
import com.cf.glesdemo.util.ShaderUtils;

/**
 * Description:圆锥
 */
public class Cone extends BaseShape {

	final String TAG = "Cone";

	private int mProgram;

	private Oval oval;
	private FloatBuffer vertexBuffer;

	private float[] mViewMatrix = new float[16];
	private float[] mProjectMatrix = new float[16];
	private float[] mMVPMatrix = new float[16];

	private int n = 360; // 切割份数
	private float height = 2.0f; // 圆锥高度
	private float radius = 1.0f; // 圆锥底面半径
	private float[] shapePositions;

	private int vSize;

	public Cone(GLSurfaceView mView) {
		super(mView);
		oval = new Oval(mView, 0);
		oval.setNoNeedClear();
		ArrayList<Float> pos = new ArrayList<>();
		pos.add(0.0f);
		pos.add(0.0f);
		pos.add(height);
		float angDegSpan = 360f / n;
		for (float i = 0; i < 360 + angDegSpan; i += angDegSpan) {
			pos.add((float) (radius * Math.sin(i * Math.PI / 180f)));
			pos.add((float) (radius * Math.cos(i * Math.PI / 180f)));
			pos.add(0.0f);
		}
		shapePositions = new float[pos.size()];
		for (int i = 0; i < shapePositions.length; i++) {
			shapePositions[i] = pos.get(i);
		}
		vSize = shapePositions.length / 3;
	}

	@Override
	public void onSurfaceCreated(GL10 gl, EGLConfig config) {
		GLES20.glEnable(GLES20.GL_DEPTH_TEST);
		GLES20.glClearColor(0.5f, 0.5f, 0.5f, 1.0f);
		vertexBuffer = allocateFloatBuffer(shapePositions);
		mProgram = ShaderUtils.createProgram(mView.getResources(),
				"vshader/Cone.sh", "fshader/Cone.sh");
		oval.onSurfaceCreated(gl, config);
	}

	@Override
	public void onSurfaceChanged(GL10 gl, int width, int height) {
		// 计算宽高比
		float ratio = (float) width / height;
		// 设置透视投影
		Matrix.frustumM(mProjectMatrix, 0, -ratio, ratio, -1, 1, 3, 20);
		// 设置相机位置
		Matrix.setLookAtM(mViewMatrix, 0, 10.0f, -10.0f, -4.0f, 0f, 0f, 0f, 0f,
				1.0f, 0.0f);
		// 计算变换矩阵
		Matrix.multiplyMM(mMVPMatrix, 0, mProjectMatrix, 0, mViewMatrix, 0);
	}

	@Override
	public void onDrawFrame(GL10 gl) {
		GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);
		GLES20.glUseProgram(mProgram);
		Log.d(TAG, "mProgram:" + mProgram);
		int mMatrix = GLES20.glGetUniformLocation(mProgram, "vMatrix");
		GLES20.glUniformMatrix4fv(mMatrix, 1, false, mMVPMatrix, 0);
		int mPositionHandle = GLES20.glGetAttribLocation(mProgram, "vPosition");
		GLES20.glEnableVertexAttribArray(mPositionHandle);
		GLES20.glVertexAttribPointer(mPositionHandle, COORDS_PER_VERTEX,
				GLES20.GL_FLOAT, false, 0, vertexBuffer);
		GLES20.glDrawArrays(GLES20.GL_TRIANGLE_FAN, 0, vSize);
		GLES20.glDisableVertexAttribArray(mPositionHandle);
		oval.setMatrix(mMVPMatrix);
		oval.onDrawFrame(gl);
	}
}
