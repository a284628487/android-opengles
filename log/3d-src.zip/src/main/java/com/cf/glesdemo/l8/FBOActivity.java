package com.cf.glesdemo.l8;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.os.Environment;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;

import com.cf.glesdemo.R;
import com.cf.glesdemo.util.Tools;

import java.nio.ByteBuffer;

/**
 * Created by ccfyyn on 18/7/1.
 */

public class FBOActivity extends AppCompatActivity implements FBORenderer.Callback {

    private GLSurfaceView mSurfaceView;

    private FBORenderer mRender;

    private Bitmap mBitmap;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mSurfaceView = new GLSurfaceView(this);
        mSurfaceView.setEGLContextClientVersion(2);

        mRender = new FBORenderer(mSurfaceView);
        mBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ic_launcher);
        mRender.setBitmap(mBitmap);
        mRender.setCallback(this);
        mSurfaceView.setRenderer(mRender);
        mSurfaceView.setRenderMode(GLSurfaceView.RENDERMODE_WHEN_DIRTY);

        setContentView(mSurfaceView);
    }

    @Override
    public void onCall(ByteBuffer data) {
        String filePath = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "gray.png";
        Tools.saveBitmapFromByteBuffer(data, mBitmap.getWidth(), mBitmap.getHeight(), filePath);
    }
}
