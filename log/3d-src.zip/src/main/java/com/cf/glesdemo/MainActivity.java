package com.cf.glesdemo;

import com.cf.glesdemo.camera.CameraActivity;
import com.cf.glesdemo.camera.CameraL9Activity;
import com.cf.glesdemo.camera.CameraSVActivity;
import com.cf.glesdemo.camera.CameraTexActivity;
import com.cf.glesdemo.l6.TextureOverlay;
import com.cf.glesdemo.l8.FBOActivity;

import android.content.Intent;
import android.graphics.BitmapFactory;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    private GLSurfaceView mSurfaceView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.e("MainActivity", "" + Thread.currentThread().toString());
        mSurfaceView = new GLSurfaceView(this);
        mSurfaceView.setEGLContextClientVersion(2);

        mSurfaceView.setRenderer(new TextureOverlay(mSurfaceView));
        mSurfaceView.setRenderMode(GLSurfaceView.RENDERMODE_WHEN_DIRTY);
        setContentView(mSurfaceView);

//        startCameraView(4);

//        startActivity(new Intent(this, TestActivity.class));

//        showFBO();
    }

    protected void startCameraView(int flag) {
        // 黑白滤镜:
        // https://blog.csdn.net/lb377463323/article/details/77096652 (Camera + TextureView)
        // https://blog.csdn.net/lb377463323/article/details/77071054 (Camera + GLSurfaceView)
        // https://blog.csdn.net/lb377463323/article/details/78054892 (Camera2 + GLSurfaceView)
        switch (flag) {
            case 1:
                startActivity(new Intent(this, CameraSVActivity.class));
                break;
            case 2:
                startActivity(new Intent(this, CameraTexActivity.class));
                break;
            case 3:
                startActivity(new Intent(this, CameraL9Activity.class));
                break;
            case 4:
                startActivity(new Intent(this, CameraActivity.class));
                break;
        }
    }

    protected void showFBO() {
        startActivity(new Intent(this, FBOActivity.class));
        //

    }

    @Override
    protected void onResume() {
        super.onResume();
        if (null != mSurfaceView)
            mSurfaceView.onResume();

    }

    @Override
    protected void onPause() {
        super.onPause();
        if (null != mSurfaceView)
            mSurfaceView.onPause();
    }
}
