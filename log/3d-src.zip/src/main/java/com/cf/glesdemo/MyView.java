package com.cf.glesdemo;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Trace;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.View;

/**
 * Created by ccfyyn on 18/7/14.
 */

// com.cf.glesdemo.MyView
public class MyView extends View {
    public MyView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public MyView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        Trace.beginSection("MyView.onDraw");

        Paint paint = new Paint();
        Rect rect = new Rect();

        try {
            Thread.sleep(50);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        Paint paint2 = new Paint();
        Rect rect2 = new Rect();

        try {
            Thread.sleep(50);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }


        paint.setColor(Color.BLUE);
        canvas.drawColor(Color.BLUE);

        postInvalidateDelayed(20);

        Trace.endSection();
    }
}
