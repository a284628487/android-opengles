package com.cf.glesdemo.gles10.render;

import android.opengl.GLSurfaceView;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/**
 * Created by ccfyyn on 17/9/23.
 */

public class Render01 implements GLSurfaceView.Renderer {

    public Render01() {
    }

    // Surface创建的时候调用
    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        // 设置清屏颜色为红色
        gl.glClearColor(1f, 0f, 0f, 0.5f);
        // 设置清屏颜色，每次清屏时，使用该颜色填充整个屏幕。里面参数分别代表RGBA，取值范围为[0,1]而不是[0,255]。
    }

    // Surface改变的的时候调用
    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {
        // 设置窗口大小
        gl.glViewport(0, 0, width, height);
    }

    // 在Surface上绘制的时候调用
    @Override
    public void onDrawFrame(GL10 gl) {
        // 清除屏幕
        gl.glClear(GL10.GL_COLOR_BUFFER_BIT);
    }

}
