package com.cf.glesdemo;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Trace;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

/**
 * Created by ccfyyn on 18/7/14.
 */

public class TestActivity extends AppCompatActivity {

    StringBuilder sb = new StringBuilder();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);
    }

    public void haha(View v) {

        Trace.beginSection("MyAdapter.onCreateViewHolder");

        Bitmap bmp1 = BitmapFactory.decodeResource(getResources(), R.drawable.android_robot0);
        Bitmap bmp2 = BitmapFactory.decodeResource(getResources(), R.drawable.android);
        Bitmap bmp3 = BitmapFactory.decodeResource(getResources(), R.drawable.texture);

        ((ImageView) findViewById(R.id.iv1)).setImageBitmap(bmp1);
        ((ImageView) findViewById(R.id.iv2)).setImageBitmap(bmp2);
        ((ImageView) findViewById(R.id.iv3)).setImageBitmap(bmp3);

        FrameLayout ct = (FrameLayout) findViewById(R.id.ct);
        Animation ani = new ScaleAnimation(1, 0.8f, 1, 0.8f);
        ani.setDuration(500);
        ani.setFillAfter(true);
        for (int i = 0; i < ct.getChildCount(); i++) {
            View c = ct.getChildAt(i);
            showText();
            try {
                Thread.sleep(50);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            c.startAnimation(ani);
        }

        Trace.endSection();
    }

    private void showText() {


        sb.delete(0, sb.length());

        openAssetsFile("fshader/BallWithLight.sh");
        openAssetsFile("fshader/Beauty.sh");
        openAssetsFile("fshader/CameraPreview.sh");
        openAssetsFile("fshader/Cone.sh");
        openAssetsFile("fshader/Texture.sh");
        openAssetsFile("fshader/Texture_Filter.sh");
        openAssetsFile("fshader/TextureShape.sh");
        openAssetsFile("fshader/overlay_vertex.sh");

        //

        openAssetsFile("fshader/BallWithLight.sh");
        openAssetsFile("fshader/Beauty.sh");
        openAssetsFile("fshader/CameraPreview.sh");
        openAssetsFile("fshader/Cone.sh");
        openAssetsFile("fshader/Texture.sh");
        openAssetsFile("fshader/Texture_Filter.sh");
        openAssetsFile("fshader/TextureShape.sh");
        openAssetsFile("fshader/overlay_vertex.sh");

        //

        openAssetsFile("fshader/BallWithLight.sh");
        openAssetsFile("fshader/Beauty.sh");
        openAssetsFile("fshader/CameraPreview.sh");
        openAssetsFile("fshader/Cone.sh");
        openAssetsFile("fshader/Texture.sh");
        openAssetsFile("fshader/Texture_Filter.sh");
        openAssetsFile("fshader/TextureShape.sh");
        openAssetsFile("fshader/overlay_vertex.sh");

        ((TextView) findViewById(R.id.tv)).setText(sb.toString());
    }

    private String openAssetsFile(String file) {
        InputStream ins = null;
        try {
            ins = getAssets().open(file);
            int len = ins.available();
            byte[] bts = new byte[len];
            ins.read(bts);
            String str = new String(bts);
            Log.e("TestActivity", "str: " + str);
            sb.append(str);
            return str;
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (null != ins)
                try {
                    ins.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
        }
        return "";
    }
}
