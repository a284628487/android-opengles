package com.cf.glesdemo.l6;

import javax.microedition.khronos.opengles.GL10;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.util.Log;

public class TextureWithFilter extends TextureShape {

	final String TAG = "TextureWithFilter";
	private FilterInput mFilter = FilterInput.NONE;
	private int changeTypeHandle;
	private int changeColorHandle;
	private int uXYHandle;
	private float uXY = 0;

	public void setFilter(FilterInput f) {
		this.mFilter = f;
	}

	public TextureWithFilter(GLSurfaceView view) {
		super(view, "vshader/TextureShape.sh", "fshader/Texture_Filter.sh");
	}

	@Override
	protected void onProgramDrawFrame() {
		super.onProgramDrawFrame();
		Log.e(TAG, "onProgramDrawFrame#");
		GLES20.glUniform1i(changeTypeHandle, mFilter.getType());
		GLES20.glUniform3fv(changeColorHandle, 1, mFilter.data(), 0);
		GLES20.glUniform1fv(uXYHandle, 1, new float[] { uXY }, 0);
	}

	@Override
	protected void onProgramCreated(int mProgram) {
		super.onProgramCreated(mProgram);
		changeTypeHandle = GLES20.glGetUniformLocation(mProgram, "vChangeType");
		changeColorHandle = GLES20.glGetUniformLocation(mProgram,
				"vChangeColor");
		uXYHandle = GLES20.glGetUniformLocation(mProgram, "uXY");
		Log.e(TAG, "onProgramCreated#");
	}

	@Override
	public void onSurfaceChanged(GL10 arg0, int width, int height) {
		super.onSurfaceChanged(arg0, width, height);
		if (null == mBitmap) {
			uXY = width * 1.0f / height;
		} else {
			uXY = mBitmap.getWidth() * 1.0f / mBitmap.getHeight();
		}
	}
}
