package com.cf.glesdemo;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;

import com.cf.glesdemo.l1.Triangle;
import com.cf.glesdemo.l2.ColorFullTriangle;
import com.cf.glesdemo.l2.RightAngleTriangle;
import com.cf.glesdemo.l3.Circle;
import com.cf.glesdemo.l3.ColoredCircle;
import com.cf.glesdemo.l3.Square;
import com.cf.glesdemo.l4.Cube;
import com.cf.glesdemo.l5.Cone;
import com.cf.glesdemo.l5.Cylinder;
import com.cf.glesdemo.l5.Oval;
import com.cf.glesdemo.l6.FilterInput;
import com.cf.glesdemo.l6.TextureBlackWhite;
import com.cf.glesdemo.l6.TextureOverlay;
import com.cf.glesdemo.l6.TextureShape;
import com.cf.glesdemo.l6.TextureWithFilter;
import com.cf.glesdemo.l7.MatrixRender;

import java.io.IOException;

public class CommonActivity extends AppCompatActivity {

    private Handler mHandler = new Handler();
    private GLSurfaceView mSurfaceView;

    private int flag = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mSurfaceView = new GLSurfaceView(this);
        mSurfaceView.setEGLContextClientVersion(2);

        // 基本图形
        if (flag == 0) {
            mSurfaceView.setRenderer(new Triangle(mSurfaceView));
        } else if (flag == 1) {
            mSurfaceView.setRenderer(new RightAngleTriangle(mSurfaceView));
        } else if (flag == 2) {
            mSurfaceView.setRenderer(new ColorFullTriangle(mSurfaceView));
        } else if (flag == 3) {
            mSurfaceView.setRenderer(new Square(mSurfaceView));
        } else if (flag == 4) {
            mSurfaceView.setRenderer(new Circle(mSurfaceView));
        } else if (flag == 5) {
            mSurfaceView.setRenderer(new ColoredCircle(mSurfaceView));
        } else if (flag == 6) {
            mSurfaceView.setRenderer(new Cube(mSurfaceView));
        } else if (flag == 7) {
            mSurfaceView.setRenderer(new Oval(mSurfaceView));
        } else if (flag == 8) {
            mSurfaceView.setRenderer(new Cone(mSurfaceView));
        } else if (flag == 9) {
            mSurfaceView.setRenderer(new Cylinder(mSurfaceView));
        }

        Bitmap bmp = null;
        try {
            bmp = BitmapFactory.decodeStream(getResources().getAssets().open("fengj.png"));
        } catch (IOException e) {
            e.printStackTrace();
            finish();
            return;
        }

        // 图片纹理
        if (flag == 11) {
            TextureShape textureShape = new TextureShape(mSurfaceView);
            textureShape.setBitmap(bmp);
            mSurfaceView.setRenderer(textureShape);
        } else if (flag == 12) {
            TextureBlackWhite textureShape = new TextureBlackWhite(mSurfaceView);
            textureShape.setBitmap(bmp);
            mSurfaceView.setRenderer(textureShape);
        } else if (flag == 13) {
            final TextureWithFilter textureShape = new TextureWithFilter(
                    mSurfaceView);
            textureShape.setFilter(FilterInput.MAGN);
            textureShape.setBitmap(bmp);
            mSurfaceView.setRenderer(textureShape);
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    System.out.println("MainActivity#onCreate");
                    textureShape.setFilter(FilterInput.GRAY);
                    mSurfaceView.requestRender();
                }
            }, 4000);
        } else if (flag == 14) { // 多重纹理
            mSurfaceView.setRenderer(new TextureOverlay(mSurfaceView));
        }

        // Matrix操作
        if (flag == 21) { // 旋转，平移等操作。
            mSurfaceView.setRenderer(new MatrixRender(mSurfaceView));
        }

        mSurfaceView.setRenderMode(GLSurfaceView.RENDERMODE_WHEN_DIRTY);
        setContentView(mSurfaceView);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (null != mSurfaceView)
            mSurfaceView.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (null != mSurfaceView)
            mSurfaceView.onPause();
    }
}
