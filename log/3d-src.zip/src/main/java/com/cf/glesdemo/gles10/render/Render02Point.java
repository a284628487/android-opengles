package com.cf.glesdemo.gles10.render;

import android.opengl.GLSurfaceView;
import android.util.Log;

import com.cf.glesdemo.util.Tools;

import java.nio.FloatBuffer;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/**
 * Created by ccfyyn on 17/9/23.
 */

public class Render02Point implements GLSurfaceView.Renderer {
    final String TAG = "Render02Point";
    private boolean mIsPoint;

    //顶点数组
    private float[] mArrayVertex = {
            0f, 0f, 0f,
            -0.95f, 0.97f, 0f,
            0.95f, -0.5f, 0f
    };

    // 缓冲区
    private FloatBuffer mBuffer;

    public Render02Point(boolean isPoint) {
        mBuffer = Tools.getFloatBuffer(mArrayVertex);
        mIsPoint = isPoint;
    }

    // Surface创建的时候调用
    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        // 设置清屏颜色
        gl.glClearColor(0.5f, 0.5f, 0.5f, 0.5f);
    }

    // Surface改变的的时候调用
    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {
        // 设置窗口大小
        Log.e(TAG, "onSurfaceChanged: " + width + " - " + height);
        gl.glViewport(0, 0, width, height);
    }

    // 在Surface上绘制的时候调用
    @Override
    public void onDrawFrame(GL10 gl) {
        // 清除屏幕
        gl.glClear(GL10.GL_COLOR_BUFFER_BIT);
        /**
         GL_COLOR_BUFFER_BIT —— 表明颜色缓冲区
         GL_DEPTH_BUFFER_BIT —— 表明深度缓冲
         GL_STENCIL_BUFFER_BIT —— 表明模型缓冲区
         */

        // 允许设置顶点
        // GL10.GL_VERTEX_ARRAY顶点数组
        gl.glEnableClientState(GL10.GL_VERTEX_ARRAY);

        // 设置顶点
        gl.glVertexPointer(3, GL10.GL_FLOAT, 0, mBuffer);
        // 设置一个指针，这个指针指向顶点数组，后面绘制三角形（或矩形）根据这里指定的顶点数组来读取数据
        /**
         size —— 每个顶点的坐标维数，必须是2, 3 或者4，初始值是4。
         type —— 指明每个顶点坐标的数据类型，允许的符号常量GL_BYTE, GL_SHORT,GL_FIXED 和GL_FLOAT，初始值为GL_FLOAT。
         stride —— 指明连续顶点间的位偏移，如果为0，顶点被认为是紧密压入矩阵，初始值为0。
         pointer —— 指明顶点坐标的缓冲区，如果为null，则没有设置缓冲区。
         */

        //设置点的颜色为红色
        gl.glColor4f(1f, 0f, 0f, 0f);

        if (mIsPoint) {
            //设置点的大小
            gl.glPointSize(20f);
            // 绘制点
            gl.glDrawArrays(GL10.GL_POINTS, 0, 3);
        } else {
            gl.glDrawArrays(GL10.GL_TRIANGLES, 0, 3);
        }


        /**
         mode：有三种取值

         GL_TRIANGLES：每三个顶之间绘制三角形，之间不连接
         GL_TRIANGLE_FAN：以V0 V1 V2,V0 V2 V3,V0 V3 V4，……的形式绘制三角形
         GL_TRIANGLE_STRIP：顺序在每三个顶点之间均绘制三角形。这个方法可以保证从相同的方向上所有三角形均被绘制。以V0 V1 V2 ,V1 V2 V3,V2 V3 V4,……的形式绘制三角形

         first：从数组缓存中的哪一位开始绘制，一般都定义为0

         count：顶点的数量
         */

        // 禁止顶点设置
        gl.glDisableClientState(GL10.GL_VERTEX_ARRAY);

    }

}

// http://blog.csdn.net/donkor_/article/details/77837863?locationNum=3&fps=1