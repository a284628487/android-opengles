package com.cf.glesdemo.l2;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;

import com.cf.glesdemo.base.BaseShape;

public class RightAngleTriangle extends BaseShape {
	private final String TAG = "ColorFulTriangle";
	// 顶点着色器(增加了矩阵变换)
	private final String vertexShaderCode = "attribute vec4 vPosition;" //
			+ "uniform mat4 vMatrix;"//
			+ "void main() {" //
			+ "  gl_Position = vMatrix * vPosition;" //
			+ "}";
	// 片元着色器
	private final String fragmentShaderCode = "precision mediump float;" //
			+ "uniform vec4 vColor;"//
			+ "void main() {"//
			+ "  gl_FragColor = vColor;"//
			+ "}";

	// 绘制顺序为逆时针
	static float triangleCoords[] = {
			//
			0.0f, 0.5f, 0.0f, // top
			-0.5f, -0.5f, 0.0f, // bottomLeft
			0.5f, -0.5f, 0.0f // bottomRight
	};
	// GLES程序id
	private int mProgram;
	// 片元着色器填充颜色
	private float color[] = { 1.0f, 1.0f, 1.0f, 1.0f };
	// 顶点坐标buffer，将传递给native层
	private FloatBuffer vertexBuffer;
	// 顶点着色器句柄
	private int mPositionHandle;
	// 变换矩阵vMatrix成员句柄
	private int mMatrixHandle;
	// 顶点着色器句柄
	private int mColorHandle;
	// 顶点偏移量
	private int vertexStride = COORDS_PER_VERTEX * 4;
	// 顶点个数
	private int vertexCount = triangleCoords.length / COORDS_PER_VERTEX;
	// 每个顶点坐标个数
	private static final int COORDS_PER_VERTEX = 3;

	private float[] mViewMatrix = new float[16];
	private float[] mProjectMatrix = new float[16];
	private float[] mMVPMatrix = new float[16];

	public RightAngleTriangle(GLSurfaceView view) {
		super(view);
		System.out.println(TAG + ": Constructor#");
	}

	@Override
	public void onDrawFrame(GL10 arg0) {
		System.out.println(TAG + ": onDrawFrame#");
		GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);
		// 将程序加入到OpenGLES2.0环境
		GLES20.glUseProgram(mProgram);
		// 获取变换矩阵vMatrix成员句柄
		mMatrixHandle = GLES20.glGetUniformLocation(mProgram, "vMatrix");
		// 指定vMatrix值
		GLES20.glUniformMatrix4fv(mMatrixHandle, 1, false, mMVPMatrix, 0);
		// 获取顶点着色器的vPosition成员句柄
		mPositionHandle = GLES20.glGetAttribLocation(mProgram, "vPosition");
		// 启用三角形顶点的句柄
		GLES20.glEnableVertexAttribArray(mPositionHandle);
		// 准备三角形的坐标数据
		GLES20.glVertexAttribPointer(mPositionHandle, COORDS_PER_VERTEX,
				GLES20.GL_FLOAT, false, vertexStride, vertexBuffer);
		// 获取片元着色器的vColor成员的句柄
		mColorHandle = GLES20.glGetUniformLocation(mProgram, "vColor");
		// 设置绘制三角形的颜色
		GLES20.glUniform4fv(mColorHandle, 1, color, 0);
		// 绘制三角形
		GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, vertexCount);
		// 禁止顶点数组的句柄
		GLES20.glDisableVertexAttribArray(mPositionHandle);
	}

	@Override
	public void onSurfaceChanged(GL10 arg0, int width, int height) {
		System.out.println(TAG + ": onSurfaceChanged#");
		// GLES20.glViewport(0, 0, width, height);
		float radio = width * 1f / height;
		// 设置透视投影
		// Matrix.frustumM(m, offset, left, right, bottom, top, near, far)
		Matrix.frustumM(mProjectMatrix, 0, -radio, radio, -1, 1, 3, 7);
		// 设置相机位置
		// Matrix.setLookAtM (float[] rm, //接收相机变换的矩阵
		// int rmOffset, //变换矩阵的起始位置（偏移量）
		// float eyeX,float eyeY, float eyeZ, //相机位置
		// float centerX,float centerY,float centerZ, //观测点位置
		// float upX,float upY,float upZ) //up向量在xyz上的分量
		Matrix.setLookAtM(mViewMatrix, 0, 0, 0, 7.0f, 0f, 0f, 0f, 0f, 1.0f,
				0.0f);
		// 计算变换矩阵
		Matrix.multiplyMM(mMVPMatrix, 0, mProjectMatrix, 0, mViewMatrix, 0);
	}

	@Override
	public void onSurfaceCreated(GL10 arg0, EGLConfig arg1) {
		System.out.println(TAG + ": onSurfaceCreated#");
		// 将背景设置为灰色
		GLES20.glClearColor(0.5f, 0.5f, 0.5f, 1.0f);
		// 申请底层空间
		ByteBuffer bb = ByteBuffer.allocateDirect(triangleCoords.length * 4);
		bb.order(ByteOrder.nativeOrder());
		// 将坐标数据转换为FloatBuffer，用以传入给OpenGL ES程序
		vertexBuffer = bb.asFloatBuffer();
		vertexBuffer.put(triangleCoords);
		vertexBuffer.position(0);
		int vertexShader = loadShader(GLES20.GL_VERTEX_SHADER, vertexShaderCode);
		int fragmentShader = loadShader(GLES20.GL_FRAGMENT_SHADER,
				fragmentShaderCode);
		// 创建一个空的OpenGLES程序
		mProgram = GLES20.glCreateProgram();
		// 将顶点着色器加入到程序
		GLES20.glAttachShader(mProgram, vertexShader);
		// 将片元着色器加入到程序中
		GLES20.glAttachShader(mProgram, fragmentShader);
		// 连接到着色器程序
		GLES20.glLinkProgram(mProgram);
	}

}
