package com.cf.glesdemo.camera;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;

import com.cf.glesdemo.R;

@SuppressLint("NewApi")
public class CameraL9Activity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_camera_cameraview);
	}
}
