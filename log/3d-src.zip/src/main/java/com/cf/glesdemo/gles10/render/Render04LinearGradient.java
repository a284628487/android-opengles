package com.cf.glesdemo.gles10.render;

import android.opengl.GLSurfaceView;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;
import javax.microedition.khronos.opengles.GL11;

/**
 * Created by ccfyyn on 17/9/24.
 */

public class Render04LinearGradient implements GLSurfaceView.Renderer {
    private boolean mTranslucentBackground;
    private Square mSquare;
    private float mTransY;

    public Render04LinearGradient(boolean useTranslucentBackground, boolean isLine) {
        mTranslucentBackground = useTranslucentBackground;
        mSquare = new Square(isLine); //3
    }

    public void onDrawFrame(GL10 gl) {//4
        gl.glClear(GL10.GL_COLOR_BUFFER_BIT | GL10.GL_DEPTH_BUFFER_BIT);//5
        gl.glMatrixMode(GL10.GL_MODELVIEW); //6
        gl.glLoadIdentity(); //7
        gl.glTranslatef(0.0f, (float) Math.sin(mTransY), -3.0f); //8
        gl.glEnableClientState(GL10.GL_VERTEX_ARRAY); //9
        gl.glEnableClientState(GL10.GL_COLOR_ARRAY);
        mSquare.draw(gl); //10
        mTransY += .075f;
    }

    public void onSurfaceChanged(GL10 gl, int width, int height) {//11
        gl.glViewport(0, 0, width, height); //12
        float ratio = (float) width / height;
        gl.glMatrixMode(GL10.GL_PROJECTION); //13
        gl.glLoadIdentity();
        gl.glFrustumf(-ratio, ratio, -1, 1, 1, 10); //14
    }

    public void onSurfaceCreated(GL10 gl, EGLConfig config) {//15
        gl.glDisable(GL10.GL_DITHER); //16
        gl.glHint(GL10.GL_PERSPECTIVE_CORRECTION_HINT, //17
                GL10.GL_FASTEST);
        if (mTranslucentBackground) {//18
            gl.glClearColor(0, 0, 0, 0);
        } else {
            gl.glClearColor(1, 1, 1, 1);
        }
        gl.glEnable(GL10.GL_CULL_FACE); //19
        gl.glShadeModel(GL10.GL_SMOOTH); //20
        gl.glEnable(GL10.GL_DEPTH_TEST); //21
    }

    public static class Square {

        private FloatBuffer mFVertexBuffer;
        private ByteBuffer mColorBuffer;
        private ByteBuffer mIndexBuffer;
        private boolean mIsLine = false;

        public Square(boolean mIsLine) {
            this.mIsLine = mIsLine;
            //we are defining our square. For larger objects, we would likely read this in from a file.
            float vertices[] = {
                    -1.0f, 1.0f, 0f,
                    -1.0f, -1.0f, 0f,
                    1.0f, -1.0f, 0f,
                    1.0f, 1.0f, 0f,
            };
            byte maxColor = (byte) 255;
            //using bytes, instead of floats is for space saving
            //(plus floats will get converted to bytes anyway, so save both space and time)
            byte colors[] = {
                    maxColor, 0, 0, maxColor,
                    0, maxColor, 0, maxColor,
                    0, maxColor, 0, maxColor,
                    maxColor, 0, 0, maxColor
            };

            byte indices[];
            // this matches up the vertices to specific triangles, the first triples says vertices 0,3,1 make triangle 0,
            if (!mIsLine) {
                indices = new byte[]{
                        0, 1, 2,
                        0, 2, 3
                };
            } else {
                indices = new byte[]{
                        0, 1,
                        0, 2,
                        2, 3,
                };
            }

            //The rest matches up everything, converts their internal java formats to the OpenGL
            //mainly makes sure the ordering of the bytes is correctly, otherwise depending on hardware, they might get reversed.
            ByteBuffer vbb = ByteBuffer.allocateDirect(vertices.length * 4);
            vbb.order(ByteOrder.nativeOrder());
            mFVertexBuffer = vbb.asFloatBuffer();
            mFVertexBuffer.put(vertices);
            mFVertexBuffer.position(0);

            mColorBuffer = ByteBuffer.allocateDirect(colors.length);
            mColorBuffer.put(colors);
            mColorBuffer.position(0);

            mIndexBuffer = ByteBuffer.allocateDirect(indices.length);
            mIndexBuffer.put(indices);
            mIndexBuffer.position(0);
        }

        public void draw(GL10 gl) {
            //tell openGL how the vertices are ordering their faces
            //this is both for efficiently so openGL can ignore the "backside" and not attempt to draw it.
            gl.glFrontFace(GL11.GL_CCW);  //counter clockwise, so any counter triangles are ignored.
            //send the buffers to the renderer
            //specific the number of elements per vertex, which there are 2.
            gl.glVertexPointer(3, GL11.GL_FLOAT, 0, mFVertexBuffer); //8
            //color buffer is added, with the size of the 4 elements
            gl.glColorPointer(4, GL11.GL_UNSIGNED_BYTE, 0, mColorBuffer); //9

            //finally draw the element, we the connectivity array, using triangles
            //could also be triangle lists, points or lines
            if (mIsLine) {
                gl.glLineWidth(20);
                gl.glDrawElements(GL11.GL_LINES, 6, GL11.GL_UNSIGNED_BYTE, mIndexBuffer);
            } else {
                gl.glDrawElements(GL11.GL_TRIANGLES, 6, GL11.GL_UNSIGNED_BYTE, mIndexBuffer);
            }

            //return the openGL back to the default value.
            gl.glFrontFace(GL11.GL_CCW); //11
        }
    }

}
