package com.cf.glesdemo;

import android.opengl.GLES20;

/**
 * Created by ccfyyn on 18/7/8.
 */

public class Test {
    //
    public static void test() {
        //

    }
}
