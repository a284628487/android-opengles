package com.cf.glesdemo.gles10.render;

import android.opengl.GLSurfaceView;
import android.opengl.GLU;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;

import javax.microedition.khronos.opengles.GL10;

/**
 * Created by ccfyyn on 17/9/24.
 */

public class Render04Square implements GLSurfaceView.Renderer {

    // Initialize our square.
    Square square = new Square();

    /*
     * (non-Javadoc)
     *
     * @see
     * android.opengl.GLSurfaceView.Renderer#onDrawFrame(javax.
         * microedition.khronos.opengles.GL10)
     */
    public void onDrawFrame(GL10 gl) {
        // Clears the screen and depth buffer.
        gl.glClear(GL10.GL_COLOR_BUFFER_BIT | // OpenGL docs.
                GL10.GL_DEPTH_BUFFER_BIT);
        // Replace the current matrix with the identity matrix
        gl.glLoadIdentity(); // OpenGL docs

        // Translates 4 units into the screen.
        gl.glTranslatef(0, 0, -8); // OpenGL docs

        // Draw our square.
        square.draw(gl); // ( NEW )
    }

    @Override
    public void onSurfaceCreated(GL10 gl, javax.microedition.khronos.egl.EGLConfig config) {
        // Set the background color to black ( rgba ).
        gl.glClearColor(0.0f, 0.0f, 0.0f, 0.5f);  // OpenGL docs.
        // Enable Smooth Shading, default not really needed.
        gl.glShadeModel(GL10.GL_SMOOTH);// OpenGL docs.
        // Depth buffer setup.
        gl.glClearDepthf(1.0f);// OpenGL docs.
        // Enables depth testing.
        gl.glEnable(GL10.GL_DEPTH_TEST);// OpenGL docs.
        // The type of depth testing to do.
        gl.glDepthFunc(GL10.GL_LEQUAL);// OpenGL docs.
        // Really nice perspective calculations.
        gl.glHint(GL10.GL_PERSPECTIVE_CORRECTION_HINT, // OpenGL docs.
                GL10.GL_NICEST);
    }

    /*
         * (non-Javadoc)
         *
         * @see
         * android.opengl.GLSurfaceView.Renderer#onSurfaceChanged(javax.
             * microedition.khronos.opengles.GL10, int, int)
         */
    public void onSurfaceChanged(GL10 gl, int width, int height) {
        // Sets the current view port to the new size.
        gl.glViewport(0, 0, width, height);// OpenGL docs.
        // Select the projection matrix
        gl.glMatrixMode(GL10.GL_PROJECTION);// OpenGL docs.
        // Reset the projection matrix
        gl.glLoadIdentity();// OpenGL docs.
        // Calculate the aspect ratio of the window
        GLU.gluPerspective(gl, 45.0f, (float) width / (float) height,
                0.1f, 100.0f);
        // Select the modelview matrix
        gl.glMatrixMode(GL10.GL_MODELVIEW);// OpenGL docs.
        // Reset the modelview matrix
        gl.glLoadIdentity();// OpenGL docs.
        //
        gl.glEnableClientState(GL10.GL_VERTEX_ARRAY);// OpenGL docs.
    }

    public class Square {
        // Our vertices.
        private float vertices[] = {
                -1.0f, 1.0f, 0.0f,  // 0, Top Left
                -1.0f, -1.0f, 0.0f,  // 1, Bottom Left
                1.0f, -1.0f, 0.0f,  // 2, Bottom Right
                1.0f, 1.0f, 0.0f,  // 3, Top Right
        };

        // The order we like to connect them.
        private short[] indices = {0, 1, 2, 0, 2, 3};
        byte maxColor = (byte) 255;
        //using bytes, instead of floats is for space saving
        //(plus floats will get converted to bytes anyway, so save both space and time)
        byte colors[] = {
                maxColor, 0, 0, maxColor,
                0, maxColor, 0, maxColor,
                0, maxColor, 0, maxColor,
                maxColor, 0, 0, maxColor
        };

        // Our vertex buffer.
        private FloatBuffer vertexBuffer;

        // Our index buffer.
        private ShortBuffer indexBuffer;

        // color buffer.
        private ByteBuffer mColorBuffer;

        public Square() {
            // a float is 4 bytes, therefore we multiply the number if
            // vertices with 4.
            ByteBuffer vbb = ByteBuffer.allocateDirect(vertices.length * 4);
            vbb.order(ByteOrder.nativeOrder());
            vertexBuffer = vbb.asFloatBuffer();
            vertexBuffer.put(vertices);
            vertexBuffer.position(0);

            // short is 2 bytes, therefore we multiply the number if
            // vertices with 2.
            ByteBuffer ibb = ByteBuffer.allocateDirect(indices.length * 2);
            ibb.order(ByteOrder.nativeOrder());
            indexBuffer = ibb.asShortBuffer();
            indexBuffer.put(indices);
            indexBuffer.position(0);

            mColorBuffer = ByteBuffer.allocateDirect(colors.length);
            mColorBuffer.put(colors);
            mColorBuffer.position(0);
        }

        /**
         * This function draws our square on screen.
         *
         * @param gl
         */
        public void draw(GL10 gl) {
            //set a color other then white, which is blue/purple

            gl.glColorPointer(4, GL10.GL_UNSIGNED_BYTE, 0, mColorBuffer);

            // Counter-clockwise winding.
            gl.glFrontFace(GL10.GL_CCW); // OpenGL docs
            // Enable face culling.
            gl.glEnable(GL10.GL_CULL_FACE); // OpenGL docs
            // What faces to remove with the face culling.
            gl.glCullFace(GL10.GL_BACK); // OpenGL docs

            // Enabled the vertices buffer for writing and to be used during
            // rendering.
            gl.glEnableClientState(GL10.GL_VERTEX_ARRAY);// OpenGL docs.
            // Specifies the location and data format of an array of vertex
            // coordinates to use when rendering.
            gl.glVertexPointer(3, GL10.GL_FLOAT, 0, // OpenGL docs
                    vertexBuffer);

            gl.glLineWidth(20);
            gl.glDrawElements(GL10.GL_TRIANGLES, 6, GL10.GL_UNSIGNED_SHORT, indexBuffer);

            // Disable the vertices buffer.
            gl.glDisableClientState(GL10.GL_VERTEX_ARRAY); // OpenGL docs
            // Disable face culling.
            gl.glDisable(GL10.GL_CULL_FACE); // OpenGL docs
        }

    }


}